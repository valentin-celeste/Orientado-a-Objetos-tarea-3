package app;

import modelo.Curso;
import modelo.Estudiante;
import modelo.Matricula;
import servicio.GestorMatricula;

public class Main {

    public static void main(String[] args) {
        GestorMatricula gestor = new GestorMatricula();

        // 1. Validacion de dato numerico con try-catch
        int cuposPoo = 2;
        String textoCupos = "treinta";
        try {
            cuposPoo = Integer.parseInt(textoCupos);
        } catch (NumberFormatException e) {
            System.out.println("[Aviso numerico] Valor '" + textoCupos + "' invalido para cupos. Se asignan " + cuposPoo + " cupos.");
        }

        Estudiante est1 = null;
        Estudiante est2 = null;
        Estudiante est3 = null;
        Curso curso1 = null;
        Curso curso2 = null;

        // 2. Instanciacion, verificacion directa y registro en GestorMatricula
        try {
            est1 = new Estudiante("E-01", "18.456.789-2", "Camila Soto", "camila.soto@correo.cl");
            est2 = new Estudiante("E-02", "19.876.543-K", "Matias Perez", "matias.perez@correo.cl");
            est3 = new Estudiante("E-03", "17.333.444-5", "Valentina Diaz", "valentina.diaz@correo.cl", false);

            curso1 = new Curso("POO-101", "Programacion Orientada a Objetos", cuposPoo);
            curso2 = new Curso("BD-201", "Bases de Datos", 2);

            // Verificacion directa de metodos de Estudiante y Curso
            System.out.println("=== Verificacion directa de entidades ===");
            System.out.println(est1.resumenEstudiante());
            System.out.println(est1.mostrarDatos());
            System.out.println("est1 habilitado para matricularse: " + est1.estaHabilitado());

            System.out.println(est3.resumenEstudiante());
            System.out.println(est3.mostrarDatos());
            System.out.println("est3 habilitado para matricularse: " + est3.estaHabilitado());

            System.out.println(curso1.resumenCurso());
            System.out.println(curso1.mostrarCurso());
            System.out.println("Tiene cupos curso1: " + curso1.tieneCupos());

            // Modificacion controlada de cupos mediante setter
            curso2.setCuposDisponibles(25);
            System.out.println("Cupos actualizados en curso2 -> " + curso2.mostrarCurso());

            // Registro de entidades (probando los metodos unificados de GestorMatricula)
            gestor.registrarEstudiante(est1);
            gestor.agregarEstudiante(est2);
            gestor.registrarEstudiante(est3);
            gestor.registrarCurso(curso1);
            gestor.agregarCurso(curso2);

        } catch (IllegalArgumentException | IllegalStateException e) {
            System.out.println("[Error de inicializacion o registro] " + e.getMessage());
        }

        // 3. Ejecucion del flujo de matriculas y pruebas de control de errores
        System.out.println("\n=== Proceso de matriculas (matricular e intentarMatricular) ===");
        gestor.matricular("MAT-01", "2026-11-23", "E-01", "POO-101");             // Exitosa
        gestor.matricular("MAT-02", "2026-11-23", "E-01", "BD-201");              // Exitosa
        gestor.matricular("MAT-03", "2026-11-23", "E-01", "POO-101");             // Error controlado: duplicada
        gestor.matricular("MAT-04", "2026-11-23", "E-02", "CURSO-INEXIST");       // Error controlado: curso no existe
        gestor.matricular("MAT-05", "2026-11-23", "E-03", "POO-101");             // Error controlado: estudiante inhabilitado
        gestor.intentarMatricular("MAT-06", "2026-11-23", "E-02", "POO-101");     // Exitosa con intentarMatricular

        // 4. Creacion directa de matricula con manejo de excepcion y consultas
        try {
            gestor.crearMatricula("MAT-07", "2026-11-23", "E-02", "BD-201");

            System.out.println("\n=== Cursos inscritos por E-01 (consultarCursosDeEstudiante) ===");
            for (Curso c : gestor.consultarCursosDeEstudiante("E-01")) {
                System.out.println("- " + c.resumenCurso());
            }

            System.out.println("\n=== Cursos inscritos por E-02 (obtenerCursosDeEstudiante) ===");
            for (Curso c : gestor.obtenerCursosDeEstudiante("E-02")) {
                System.out.println("- " + c.resumenCurso());
            }

            System.out.println("\n=== Matriculas de Camila Soto (buscarMatriculasPorEstudiante) ===");
            for (Matricula m : gestor.buscarMatriculasPorEstudiante("E-01")) {
                System.out.println("- " + m.mostrarDetalleMatricula());
            }

        } catch (IllegalArgumentException | IllegalStateException e) {
            System.out.println("[Error en operacion de matricula] " + e.getMessage());
        }

        // 5. Prueba de validacion: intento de asignar cupos negativos
        System.out.println("\n=== Prueba de validacion de cupos negativos ===");
        try {
            if (curso2 != null) {
                curso2.setCuposDisponibles(-5);
            }
        } catch (IllegalArgumentException e) {
            System.out.println("[Error de validacion] " + e.getMessage());
        }

        // 6. Reportes consolidados finales
        System.out.println("\n=== Listado de matriculas (listarMatriculas) ===");
        gestor.listarMatriculas();

        gestor.mostrarResumenGeneral();

        System.out.println("\nPrograma finalizado de forma controlada.");
    }
}