package modelo;

public class Matricula {

    private String codigoMatricula;
    private String fechaMatricula;
    private boolean activa;
    private Estudiante estudiante; // Referencia asociada a Estudiante
    private Curso curso;           // Referencia asociada a Curso

    public Matricula(String codigoMatricula, String fechaMatricula, Estudiante estudiante, Curso curso) {
        setCodigoMatricula(codigoMatricula);
        setFechaMatricula(fechaMatricula);

        if (estudiante == null) {
            throw new IllegalArgumentException("La matricula debe tener un estudiante valido asociado.");
        }
        if (curso == null) {
            throw new IllegalArgumentException("La matricula debe tener un curso existente asociado.");
        }
        if (!estudiante.estaHabilitado()) {
            throw new IllegalStateException("El estudiante " + estudiante.getIdEstudiante() + " no esta habilitado para matricularse.");
        }

        curso.descontarCupo();
        this.estudiante = estudiante;
        this.curso = curso;
        this.activa = true;
    }

    public String getCodigoMatricula() {
        return codigoMatricula;
    }

    public void setCodigoMatricula(String codigoMatricula) {
        if (codigoMatricula == null || codigoMatricula.trim().isEmpty()) {
            throw new IllegalArgumentException("El codigo de matricula no puede estar vacio.");
        }
        this.codigoMatricula = codigoMatricula.trim();
    }

    public String getFechaMatricula() {
        return fechaMatricula;
    }

    public void setFechaMatricula(String fechaMatricula) {
        if (fechaMatricula == null || fechaMatricula.trim().isEmpty()) {
            throw new IllegalArgumentException("La fecha de matricula no puede estar vacia.");
        }
        this.fechaMatricula = fechaMatricula.trim();
    }

    public boolean isActiva() {
        return activa;
    }

    public Estudiante getEstudiante() {
        return estudiante;
    }

    public Curso getCurso() {
        return curso;
    }

    public void anularMatricula() {
        if (this.activa) {
            this.activa = false;
            this.curso.liberarCupo();
        }
    }

    public String resumenMatricula() {
        String estado = activa ? "Activa" : "Anulada";
        return "Matricula [" + codigoMatricula + "] (" + fechaMatricula + ", " + estado + ") -> " +
                estudiante.getNombreCompleto() + " [" + estudiante.getIdEstudiante() + "] en " +
                curso.getNombreCurso() + " [" + curso.getCodigoCurso() + "]";
    }

    public String resumenDetallado() {
        String estado = activa ? "Activa" : "Anulada";
        return "[" + codigoMatricula + "] Fecha: " + fechaMatricula + " | Estado: " + estado +
                " | Estudiante: " + estudiante.getNombreCompleto() + " (" + estudiante.getIdEstudiante() + ")" +
                " | Curso: " + curso.getNombreCurso() + " (" + curso.getCodigoCurso() + ")";
    }

    public String mostrarDetalleMatricula() {
        String estado = activa ? "Activa" : "Anulada";
        return "Matricula [" + codigoMatricula + "] (" + fechaMatricula + ", " + estado + ") -> " +
                estudiante.getNombreCompleto() + " en " + curso.getNombreCurso();
    }
}