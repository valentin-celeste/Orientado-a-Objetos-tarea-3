package modelo;

public class Estudiante {

    private String idEstudiante;
    private String rut;
    private String nombreCompleto;
    private String correo;
    private boolean activo;

    // Constructor completo: inicializa todos los atributos validados
    public Estudiante(String idEstudiante, String rut, String nombreCompleto, String correo, boolean activo) {
        setIdEstudiante(idEstudiante);
        setRut(rut);
        setNombreCompleto(nombreCompleto);
        setCorreo(correo);
        setActivo(activo);
    }

    // Constructor sobrecargado: por defecto deja al estudiante activo (true)
    public Estudiante(String idEstudiante, String rut, String nombreCompleto, String correo) {
        this(idEstudiante, rut, nombreCompleto, correo, true);
    }

    public String getIdEstudiante() {
        return idEstudiante;
    }

    public void setIdEstudiante(String idEstudiante) {
        if (idEstudiante == null || idEstudiante.trim().isEmpty()) {
            throw new IllegalArgumentException("El ID del estudiante no puede estar vacio.");
        }
        this.idEstudiante = idEstudiante.trim();
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        if (rut == null || rut.trim().isEmpty()) {
            throw new IllegalArgumentException("El RUT es obligatorio.");
        }
        this.rut = rut.trim();
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        if (nombreCompleto == null || nombreCompleto.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre completo es obligatorio.");
        }
        this.nombreCompleto = nombreCompleto.trim();
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        if (correo == null || !correo.contains("@") || !correo.contains(".")) {
            throw new IllegalArgumentException("El correo electronico no es valido.");
        }
        this.correo = correo.trim();
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public boolean estaHabilitado() {
        return activo;
    }

    public String resumenEstudiante() {
        return "[" + idEstudiante + "] " + nombreCompleto +
                " | RUT: " + rut +
                " | Correo: " + correo +
                " | Habilitado: " + activo;
    }

    public String resumenDetallado() {
        return "[" + idEstudiante + "] " + nombreCompleto + " (RUT: " + rut +
                ") - Correo: " + correo + " - Habilitado: " + activo;
    }

    public String mostrarDatos() {
        return "ID: " + idEstudiante + " | RUT: " + rut + " | Nombre: " + nombreCompleto +
                " | Correo: " + correo + " | Activo: " + activo;
    }
}