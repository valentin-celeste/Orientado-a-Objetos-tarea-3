package servicio;

import java.util.ArrayList;
import java.util.List;
import modelo.Curso;
import modelo.Estudiante;
import modelo.Matricula;

public class GestorMatricula {

    private List<Estudiante> estudiantes; // Agregacion de estudiantes
    private List<Curso> cursos;           // Agregacion de cursos
    private List<Matricula> matriculas;   // Agregacion de matriculas

    public GestorMatricula() {
        this.estudiantes = new ArrayList<>();
        this.cursos = new ArrayList<>();
        this.matriculas = new ArrayList<>();
    }

    // --- Registro y búsqueda de Estudiantes ---

    public void registrarEstudiante(Estudiante estudiante) {
        if (estudiante == null) {
            throw new IllegalArgumentException("No se puede registrar un estudiante nulo.");
        }
        if (buscarEstudiantePorId(estudiante.getIdEstudiante()) != null) {
            throw new IllegalArgumentException("Ya existe un estudiante registrado con ID: " + estudiante.getIdEstudiante());
        }
        estudiantes.add(estudiante);
    }

    public void agregarEstudiante(Estudiante estudiante) {
        registrarEstudiante(estudiante);
    }

    public Estudiante buscarEstudiantePorId(String idEstudiante) {
        if (idEstudiante == null) {
            return null;
        }
        for (Estudiante e : estudiantes) {
            if (e.getIdEstudiante().equalsIgnoreCase(idEstudiante.trim())) {
                return e;
            }
        }
        return null;
    }

    // --- Registro y búsqueda de Cursos ---

    public void registrarCurso(Curso curso) {
        if (curso == null) {
            throw new IllegalArgumentException("No se puede registrar un curso nulo.");
        }
        if (buscarCursoPorCodigo(curso.getCodigoCurso()) != null) {
            throw new IllegalArgumentException("Ya existe un curso registrado con codigo: " + curso.getCodigoCurso());
        }
        cursos.add(curso);
    }

    public void agregarCurso(Curso curso) {
        registrarCurso(curso);
    }

    public Curso buscarCursoPorCodigo(String codigoCurso) {
        if (codigoCurso == null) {
            return null;
        }
        for (Curso c : cursos) {
            if (c.getCodigoCurso().equalsIgnoreCase(codigoCurso.trim())) {
                return c;
            }
        }
        return null;
    }

    // --- Proceso de Matrícula ---

    public Matricula matricularEstudiante(String codigoMatricula, String fecha, String idEstudiante, String codigoCurso) {
        Estudiante est = buscarEstudiantePorId(idEstudiante);
        if (est == null) {
            throw new IllegalArgumentException("No existe un estudiante con ID '" + idEstudiante + "'.");
        }

        Curso cur = buscarCursoPorCodigo(codigoCurso);
        if (cur == null) {
            throw new IllegalArgumentException("No se puede matricular: el curso '" + codigoCurso + "' no existe.");
        }

        for (Matricula m : matriculas) {
            if (m.isActiva()
                    && m.getEstudiante().getIdEstudiante().equalsIgnoreCase(est.getIdEstudiante())
                    && m.getCurso().getCodigoCurso().equalsIgnoreCase(cur.getCodigoCurso())) {
                throw new IllegalArgumentException("El estudiante " + est.getIdEstudiante() +
                        " ya esta matriculado en el curso " + cur.getCodigoCurso() + ".");
            }
        }

        Matricula nuevaMatricula = new Matricula(codigoMatricula, fecha, est, cur);
        matriculas.add(nuevaMatricula);
        return nuevaMatricula;
    }

    public Matricula crearMatricula(String codigoMatricula, String fecha, String idEstudiante, String codigoCurso) {
        return matricularEstudiante(codigoMatricula, fecha, idEstudiante, codigoCurso);
    }

    public boolean matricular(String codigoMatricula, String fecha, String idEstudiante, String codigoCurso) {
        try {
            Matricula nuevaMatricula = matricularEstudiante(codigoMatricula, fecha, idEstudiante, codigoCurso);
            System.out.println("[OK] " + nuevaMatricula.resumenMatricula());
            return true;
        } catch (IllegalArgumentException | IllegalStateException e) {
            System.out.println("[Error controlado en matricula " + codigoMatricula + "] " + e.getMessage());
            return false;
        }
    }

    public boolean intentarMatricular(String codigoMatricula, String fecha, String idEstudiante, String codigoCurso) {
        try {
            Matricula nueva = matricularEstudiante(codigoMatricula, fecha, idEstudiante, codigoCurso);
            System.out.println("Matricula registrada correctamente: " + nueva.resumenMatricula());
            return true;
        } catch (IllegalArgumentException | IllegalStateException e) {
            System.out.println("[Aviso] No se completo la matricula (" + codigoMatricula + "): " + e.getMessage());
            return false;
        }
    }

    // --- Consultas y Reportes ---

    public List<Matricula> buscarMatriculasPorEstudiante(String idEstudiante) {
        List<Matricula> resultado = new ArrayList<>();
        if (idEstudiante == null) {
            return resultado;
        }
        for (Matricula m : matriculas) {
            if (m.getEstudiante().getIdEstudiante().equalsIgnoreCase(idEstudiante.trim())) {
                resultado.add(m);
            }
        }
        return resultado;
    }

    public List<Curso> consultarCursosDeEstudiante(String idEstudiante) {
        List<Curso> inscritos = new ArrayList<>();
        if (idEstudiante == null) {
            return inscritos;
        }
        for (Matricula m : matriculas) {
            if (m.isActiva() && m.getEstudiante().getIdEstudiante().equalsIgnoreCase(idEstudiante.trim())) {
                inscritos.add(m.getCurso());
            }
        }
        return inscritos;
    }

    public List<Curso> obtenerCursosDeEstudiante(String idEstudiante) {
        return consultarCursosDeEstudiante(idEstudiante);
    }

    public void listarMatriculas() {
        if (matriculas.isEmpty()) {
            System.out.println("No hay matriculas registradas.");
            return;
        }
        for (Matricula m : matriculas) {
            System.out.println(m.resumenMatricula());
        }
    }

    public void mostrarMatriculas() {
        listarMatriculas();
    }

    public void mostrarResumenGeneral() {
        System.out.println("\n--- Estudiantes ---");
        for (Estudiante e : estudiantes) {
            System.out.println(e.resumenEstudiante());
        }

        System.out.println("\n--- Cursos ---");
        for (Curso c : cursos) {
            System.out.println(c.resumenCurso());
        }

        System.out.println("\n--- Matriculas ---");
        if (matriculas.isEmpty()) {
            System.out.println("Sin matriculas registradas.");
        } else {
            for (Matricula m : matriculas) {
                System.out.println(m.resumenMatricula());
            }
        }
    }
}