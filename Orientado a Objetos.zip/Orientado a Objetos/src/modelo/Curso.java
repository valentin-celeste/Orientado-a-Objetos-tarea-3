package modelo;

public class Curso {

    private String codigoCurso;
    private String nombreCurso;
    private int cuposDisponibles;

    // Constructor completo
    public Curso(String codigoCurso, String nombreCurso, int cuposDisponibles) {
        setCodigoCurso(codigoCurso);
        setNombreCurso(nombreCurso);
        setCuposDisponibles(cuposDisponibles);
    }

    // Constructor sobrecargado: inicia con 30 cupos por defecto
    public Curso(String codigoCurso, String nombreCurso) {
        this(codigoCurso, nombreCurso, 30);
    }

    public String getCodigoCurso() {
        return codigoCurso;
    }

    public void setCodigoCurso(String codigoCurso) {
        if (codigoCurso == null || codigoCurso.trim().isEmpty()) {
            throw new IllegalArgumentException("El codigo del curso no puede estar vacio.");
        }
        this.codigoCurso = codigoCurso.trim();
    }

    public String getNombreCurso() {
        return nombreCurso;
    }

    public void setNombreCurso(String nombreCurso) {
        if (nombreCurso == null || nombreCurso.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del curso es obligatorio.");
        }
        this.nombreCurso = nombreCurso.trim();
    }

    public int getCuposDisponibles() {
        return cuposDisponibles;
    }

    public void setCuposDisponibles(int cuposDisponibles) {
        if (cuposDisponibles < 0) {
            throw new IllegalArgumentException("Los cupos disponibles no pueden ser negativos.");
        }
        this.cuposDisponibles = cuposDisponibles;
    }

    public boolean tieneCupos() {
        return cuposDisponibles > 0;
    }

    public void descontarCupo() {
        if (!tieneCupos()) {
            throw new IllegalStateException("No quedan cupos disponibles en el curso " + codigoCurso);
        }
        this.cuposDisponibles--;
    }

    public void liberarCupo() {
        this.cuposDisponibles++;
    }

    public String resumenCurso() {
        return "[" + codigoCurso + "] " + nombreCurso + " | Cupos disponibles: " + cuposDisponibles;
    }

    public String resumenConGuion() {
        return "[" + codigoCurso + "] " + nombreCurso + " - Cupos disponibles: " + cuposDisponibles;
    }

    public String mostrarCurso() {
        return "Curso: [" + codigoCurso + "] " + nombreCurso + " | Cupos: " + cuposDisponibles;
    }
}